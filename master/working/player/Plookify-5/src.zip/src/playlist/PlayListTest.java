/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playlist;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.sql.*;
import javax.swing.JOptionPane;

public class PlayListTest {

	private String name;
	private ArrayList<Integer> songList;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Integer> getSongList() {
		return songList;
	}

	public void setSongList(ArrayList<Integer> songList) {
		this.songList = songList;
	}

	public void PlayList() {
		name = "Untitled";
		songList = new ArrayList<Integer>();
	}

	public void PlayList(String name) {
		this.name = name;
		songList = new ArrayList<Integer>();
	}

	

	
        public static boolean rsCheck(ResultSet rs)
        {
            boolean check = false;
            try
            {
                check = true;
                rs.next();
            }
            catch(Exception e)
            {
                check = false;        
                JOptionPane.showMessageDialog(null, "hey");
           
            }
            System.out.println(check);
            return check;
        }


        public static ArrayList<Integer> getSongList(String artistName)
        {
            ArrayList<Integer> songListIndex = new ArrayList<Integer>();
            try {
            int artistID=-1;    
                
            Connection con = null;
            Statement st = null, st1 = null;
            ResultSet rs = null, rs1 = null;
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:PlaylistDatabase.sqlite");
            st = con.createStatement();
            st1 = con.createStatement();
            rs = st.executeQuery("SELECT * FROM Artist");
            rs1 = st1.executeQuery("SELECT * FROM Track");
            while (rs.next()) //hasNext()
            {
                String trackArtist = rs.getString("artist_name");
                if (trackArtist.equalsIgnoreCase(artistName))
                {
                    artistID = rs.getInt("artist_id");
                    break;
                }
            }
           int index1 =0;
            while (rs1.next())
            {
                int temp_artistID = rs1.getInt("artist_id");
                if (temp_artistID == artistID)
                {
                    String songName = rs1.getString("track_name");
                    int index = rs1.getInt("track_id");
                   System.out.println(songName);
                    songListIndex.add(index);
                }
               System.out.println(index1);
                index1++;
            }
            
           
           rs.close();
           rs1.close();
           st.close();
           st1.close();
           con.close();
           
           return songListIndex;
           
        }
        catch (Exception e) 
            {
            System.out.println(""+e);
            }
            
        return null; // this being returned means there is an error
        }   


	
	
	
	
	public static void main(String[] args) {
//		PlayList p = new PlayList();
//		p.loadSongs("sample.txt");
//		System.out.println(p.getSongList());
//		p.sortByArtist();
//		System.out.println(p.getSongList());
//                PlayList p = new PlayList();
                ArrayList<Integer> array = getSongList("One Direction");
//                array.get(0);
//                
//                p.createNewPlaylist("OD", array, false);
//                p.printAll();
//                JOptionPane.showMessageDialog(null, "print");
//                
//                p.rename("OD", "One Direction");
//                p.addSong("One Direction", 0);
//                
////                System.out.println(p.playlistName.get(0));
//                p.printAll();
//                
//                JOptionPane.showMessageDialog(null, "print");
//                System.out.println(p.createNewPlaylist("One Direction", null, true));
//                JOptionPane.showMessageDialog(null, "print");
//                getSongList("One Direction");
	}
	
	
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playlist;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
/**
 *
 * @author Farrah
 */
public class ConnectoDB {
    


    public  static void main(String args[]){
        Connection connect = null;
        Statement state = null;
        ResultSet rs;
        
        try{
            Class.forName("org.sqlite.JDBC");
            
           //   String locateDB = "jdbc:sqlite:///Users/Farrah/Desktop/NetBeansSE7/SE7/Plookify/src/Playlist/PlaylistDatabase.sqlite"; 
           
            
            
            connect = DriverManager.getConnection("jdbc:sqlite:PlaylistDatabase.sqlite");
            System.out.println("Database open successful");
            
            state = connect.createStatement();
            String sql = "CREATE TABLE TESTER1" +
                           "(ID     INT     PRIMARY KEY     NOT NULL)"; 
            
            System.out.println("runs till here");
//            rs = state.executeQuery(sql);
            
            state.executeUpdate(sql);       //saving table
            state.close();          //close statement
            connect.close();        //close database
            System.out.println("Table creation successful");        //done
        }
        
        catch(ClassNotFoundException | SQLException e){
            System.out.print(e);
        }
                
    }

    private void close() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Statement createStatement() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
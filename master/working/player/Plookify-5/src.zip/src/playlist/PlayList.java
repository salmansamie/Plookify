/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playlist;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Farrah
 */
public class PlayList 
{
    
    ArrayList<ArrayList<Integer>> playlists; //integer stored are song id's
    ArrayList<String> playlistName;
    ArrayList<Boolean> friend;
    
    PlayList()
    {
        playlists = new ArrayList<ArrayList<Integer>>() ;
        playlistName = new ArrayList<String>();
        friend = new ArrayList<Boolean>();
    }
    
    public boolean createNewPlaylist(String playlist_Name, ArrayList<Integer> playList, boolean friend)
    {
        for (int i=0; i<playlistName.size(); i++)
        {
            if (playlistName.get(i).equalsIgnoreCase(playlist_Name))
            {
                return false;
            }
        }
        this.playlistName.add(playlist_Name);
        playlists.add(playList);
        this.friend.add(friend);
        return true;
    }
    
    public boolean deletePlayList(String playlist_name)
    {
        for (int i=0; i<playlistName.size(); i++)
        {
            if (playlistName.get(i).equalsIgnoreCase(playlist_name))
            {
                playlistName.remove(i);
                playlists.remove(i);
                friend.remove(i);
                return true;
            }
                
        }  
        return false;
    }
    
    public boolean rename(String old_name, String newName)
    {
        for (int i=0; i<playlistName.size(); i++)
        {
            if (playlistName.get(i).equalsIgnoreCase(old_name))
            {
               JOptionPane.showMessageDialog(null, (i+""));
               playlistName.set( i, newName );
               return true;
            }   
        }  
        return false;
    }
    
    public boolean addSong(String playlist_Name, int songId)
    {
        for (int i=0; i<playlistName.size(); i++)
        {
            if (playlistName.get(i).equalsIgnoreCase(playlist_Name))
            {
               (playlists.get(i)).add(songId);
            }   
        }  
        return false;
    }
    
    public void printAll()
    {
        for (int i=0; i<playlistName.size(); i++)
        {
            System.out.println(playlistName.get(i));
            for (int j=0; j<playlists.get(i).size(); j++)
            {
                System.out.println(playlists.get(i).get(j));
            }
        }
    }
        
    
}




